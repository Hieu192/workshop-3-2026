export const config = {
  apiUrl: 'https://hqimmnzmvs.ap-southeast-1.awsapprunner.com',
  region: 'ap-southeast-1',
  identityPoolId: 'us-east-1:d8009b94-a448-44b7-8126-2fce9a0cd1f7',
  websocketUrl: 'wss://kvtige2lb3.execute-api.ap-southeast-1.amazonaws.com/prod/'
};
